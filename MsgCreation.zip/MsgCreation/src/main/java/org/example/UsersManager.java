package org.example;

import org.example.BaseClasses.User;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class UsersManager {
    private final String databaseURL;
    public UsersManager(String dbURL){
        databaseURL = dbURL;
    }
    public String getDatabaseURL() {
        return databaseURL;
    }

    public int addUsr (String username, String password){
        if (!usrExist(username)){
            try (Connection connection = DriverManager.getConnection(databaseURL,"root", "")){
                String sqlQuery;

                sqlQuery = "INSERT INTO Users (username, password) VALUES(?, ?)";  //in database mytestdb, tabella allievi4g, (nome campo1, 2) (VALUES(placeholder1, 2) valori che verranno travasati nei campi)

                password = hashMd5(password);
                if(password == null){
                    return -1;
                }

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                preparedStatement.setString(1, username);  //1: nel primo campo inserisco la stringa
                preparedStatement.setString(2, password); //2: nel secondo campo inserisco la stringa

                //phoneNumber null

                int result = preparedStatement.executeUpdate();

                if(result>0){
//                    System.out.println("Row Created");
                    return 0;
                }
            }catch (SQLException ex){
                System.err.printf("Errore: ");
                ex.printStackTrace();
            }
        } else {
            System.out.println("Esiste già un utente con questo username");
            return 1;
        }

        return -1;
    }

    public int addUsr (User usr){
        String username = usr.getUsername();
        String password = usr.getPassword();
        if (!usrExist(username)){
            try (Connection connection = DriverManager.getConnection(databaseURL,"root", "")){
                String sqlQuery;

                sqlQuery = "INSERT INTO Users (username, password) VALUES(?, ?)";  //in database mytestdb, tabella allievi4g, (nome campo1, 2) (VALUES(placeholder1, 2) valori che verranno travasati nei campi)

                password = hashMd5(password);
                if(password == null){
                    return -1;
                }

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                preparedStatement.setString(1, username);  //1: nel primo campo inserisco la stringa
                preparedStatement.setString(2, password); //2: nel secondo campo inserisco la stringa

                //phoneNumber null

                int result = preparedStatement.executeUpdate();

                if(result>0){
                    //                    System.out.println("Row Created");
                    return 0;
                }
            }catch (SQLException ex){
                System.err.printf("Errore: ");
                ex.printStackTrace();
            }
        } else {
            System.out.println("Esiste già un utente con questo username");
            return 1;
        }

        return -1;
    }

    public int addUsrFull (String username, String mail, String password, String Nome, String Cognome){
        if (!usrExist(username)){
            try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
                String sqlQuery;
                sqlQuery = "INSERT INTO Users (username, mail, password, Nome, Cognome) VALUES(?, ?, ?, ?, ?)";  //in database mytestdb, tabella allievi4g, (nome campo1, 2) (VALUES(placeholder1, 2) valori che verranno travasati nei campi)

                password = hashMd5(password);
                if(password == null){
                    return -1;
                }

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                preparedStatement.setString(1, username);  //1: nel primo campo inserisco la stringa
                preparedStatement.setString(2, mail); //2: nel secondo campo inserisco la stringa
                preparedStatement.setString(3, password);
                preparedStatement.setString(4, Nome);
                preparedStatement.setString(5, Cognome);
                //phoneNumber null

                int result = preparedStatement.executeUpdate();

                if(result>0){
                    System.out.println("Row Created");
                    return 0;
                }
            }catch (SQLException ex){
                System.err.printf("Errore: ");
                ex.printStackTrace();
                return 1;
            }
        } else {
            System.out.println("Esiste già un utente con questo username");
        }
        return -1;
    }

    public int addUsrFull (User usr){

        String username = usr.getUsername();
        String password = usr.getPassword();
        String mail = usr.getEmail();
        String nome = usr.getName();
        String cognome = usr.getSurname();

        if (!usrExist(username)){
            try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
                String sqlQuery;
                sqlQuery = "INSERT INTO Users (username, mail, password, Nome, Cognome) VALUES(?, ?, ?, ?, ?)";  //in database mytestdb, tabella allievi4g, (nome campo1, 2) (VALUES(placeholder1, 2) valori che verranno travasati nei campi)

                password = hashMd5(password);
                if(password == null){
                    return -1;
                }

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                preparedStatement.setString(1, username);  //1: nel primo campo inserisco la stringa
                preparedStatement.setString(2, mail); //2: nel secondo campo inserisco la stringa
                preparedStatement.setString(3, password);
                preparedStatement.setString(4, nome);
                preparedStatement.setString(5, cognome);
                //phoneNumber null

                int result = preparedStatement.executeUpdate();

                if(result>0){
                    System.out.println("Row Created");
                    return 0;
                }
            }catch (SQLException ex){
                System.err.printf("Errore: ");
                ex.printStackTrace();
                return 1;
            }
        } else {
            System.out.println("Esiste già un utente con questo username");
        }
        return -1;
    }

    public boolean usrExist (String usrname){
        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
            String sqlQuery;
            sqlQuery = "SELECT * FROM users WHERE username = ? ";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, usrname);

            ResultSet rs = preparedStatement.executeQuery();
            return rs.next();
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
        return false;
    }

    public boolean usrExist (User usr){
        String usrname = usr.getUsername();

        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
            String sqlQuery;
            sqlQuery = "SELECT * FROM users WHERE username = ? ";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, usrname);

            ResultSet rs = preparedStatement.executeQuery();
            return rs.next();
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
        return false;
    }

    public boolean login (String usrname, String psw){
        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){

            psw = hashMd5(psw);
            if(psw == null){
                return false;
            }

            String sqlQuery;
            sqlQuery = "SELECT * FROM users WHERE username = ? AND password = ? LIMIT 1";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, usrname);
            preparedStatement.setString(2, psw);

            //Statement statement = connection.createStatement();
            ResultSet rs = preparedStatement.executeQuery();
            return rs.next();
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
        return false;
    }

    public boolean login (User usr){
        String usrname = usr.getUsername();
        String psw = usr.getPassword();

        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){

            psw = hashMd5(psw);
            if(psw == null){
                return false;
            }

            String sqlQuery;
            sqlQuery = "SELECT * FROM users WHERE username = ? AND password = ? LIMIT 1";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, usrname);
            preparedStatement.setString(2, psw);

            //Statement statement = connection.createStatement();
            ResultSet rs = preparedStatement.executeQuery();
            return rs.next();
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
        return false;
    }

    public static String hashMd5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");    //md calcolerà md5
            byte[] hashBytes = md.digest(input.getBytes());     //md calcola md5 sull'input convertito in byte

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);     //java usa byte con segno (-127 -> 127) ma per trasformarlo in stringa deve essere sempre positivo
                if (hex.length() == 1) hexString.append('0');     //1 byte = 2 cifre esa -> nel caso in cui e' solo una aggiungo 0 prima di aggiungere la cifra calcolata
                hexString.append(hex);                            //aggiungo la cifra esa
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
        return null;
    }


}