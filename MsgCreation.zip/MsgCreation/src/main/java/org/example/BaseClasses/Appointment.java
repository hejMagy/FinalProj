package org.example.BaseClasses;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;

public class Appointment{
    private ArrayList<User> members;       //o lo facciamo come pensa vecchi oppure come fa whatsapp, cioe' sono le persone che hanno confermato la presenza
    private Calendar date;
    private String place;
    private String descr;

    Appointment(ArrayList<User> mem, Calendar date, String place, String descr){
        members = mem;
        this.date = date;
        this.place = place;
        this.descr = descr;
    }

    //SETTERS E GETTERS
    public void setDate(Calendar date) {
        this.date = date;
    }
    public void setDescr(String descr) {
        this.descr = descr;
    }
    public void setPlace(String place) {
        this.place = place;
    }
    public Calendar getDate() {
        return date;
    }
    public String getDescr() {
        return descr;
    }
    public String getPlace() {
        return place;
    }

    //METODI
    public Duration countdown(){
        Instant instant1 = Calendar.getInstance().toInstant();
        Instant instant2 = date.toInstant();

        return Duration.between(instant1, instant2);
    }
    public void removeUser(User us){
        members.remove(us);
    }
    //TODO pensare ad altri metodi utili

}