package org.example.BaseClasses;

import org.example.*;
//import org.example.Chat;

import java.util.ArrayList;

public class Project {
//    private ArrayList<User> members;
    private ArrayList<Integer> membersID;
    private String name;
    private String description;
    private Chat chat;
    //TODO: progetto da fare (non serve più)
    public Project(ArrayList<Integer>members, String name, String description){
        this.membersID = members;
        this.name = name;
        this.description = description;
    }
    public ArrayList<Integer> getMembers(){
        return membersID;
    }
    public void setMembers(ArrayList<Integer> members){
        this.membersID=members;
    }
    public void addMember (int usrID) {
        membersID.add(usrID);
    }
    public void removeMember (int usrID) {
        membersID.remove(usrID);
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setDescription(String description){
        this.description=description;
    }
    public String getDescription(){
        return description;
    }
    @Override
    public String toString(){
        return "Team{" +
                "members=" + membersID +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}