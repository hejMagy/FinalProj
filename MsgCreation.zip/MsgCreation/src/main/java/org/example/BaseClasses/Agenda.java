package org.example.BaseClasses;

import java.util.ArrayList;
//TODO da completare
public class Agenda{
    private ArrayList<Appointment>notes;
    public Agenda(ArrayList<Appointment>notes){
        this.notes=notes;
    }
    public ArrayList<Appointment> getNotes(){
        return notes;
    }
    public void setNotes(ArrayList<Appointment>notes){
        this.notes=notes;
    }



}