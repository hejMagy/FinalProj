package org.example.BaseClasses;

import java.util.ArrayList;
import java.util.Calendar;

public class Main {
    public static void main(String[] args) {
        ArrayList <Message> messages = new ArrayList<>();
        Calendar currDatenTime = Calendar.getInstance();
        User usr = new User("Gaia", "Zhou", "gaiga", "", "jdnsj", "");
        messages.add(new Message("ciao", usr, currDatenTime, messages.size(), 0));
        System.out.println(messages.get(0).toString());
    }
}
