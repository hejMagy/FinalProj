package org.example.BaseClasses;

import java.util.Calendar;

public class Message {
    private String txtContent;  //Message Content
    private User user; //User (sender)
    private Calendar date;   //Sending Date
    private int msgID;     //Msg ID
    private int prjID;


     public Message(String msg, User usr, Calendar date, int lastID, int prjID){
        txtContent = msg;
        user = usr;
        this.date = date;
        msgID = lastID++;
        this.prjID = prjID;
     }

     public String getTxtContent() {
         return txtContent;
     }

     public User getUser(){
        return user;
     }

     public Calendar getDate(){
        return date;
     }

    public int getPrjID() {
        return prjID;
    }

    public String toString(){
         return txtContent + "\n" + msgID + " il " + date;
     }
}
