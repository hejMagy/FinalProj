package org.example;

import org.example.BaseClasses.*;

import java.sql.*;
import java.util.Calendar;

public class Chat {
    private final String databaseURL;

    public Chat(String dbURL){
        databaseURL = dbURL;
    }

    public String getDatabaseURL() {
        return databaseURL;
    }

    public boolean sendMss(Message mss){
        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
            String sqlQuery;
            String username = mss.getUser().getUsername();
            String mssContent = mss.getTxtContent();
            Calendar date = mss.getDate();
            String prjID = Integer.toString(mss.getPrjID());
            String dateStr;

            int year = date.get(Calendar.YEAR);
            int month = date.get(Calendar.MONTH) + 1; // mesi: 0-11
            int day = date.get(Calendar.DAY_OF_MONTH);
            int hour = date.get(Calendar.HOUR_OF_DAY); // 24h format
            int minute = date.get(Calendar.MINUTE);
            int second = date.get(Calendar.SECOND);

            // Formatta la stringa come "YYYY-MM-DD" con zeri iniziali
            dateStr = String.format("%04d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, minute, second);

            sqlQuery = "INSERT INTO messaggi (Messaggio, Username, Data, projectID) VALUES(?, ?, ?, ?)";  //nome tabella, (nome campo1, 2) (VALUES(placeholder1, 2) valori che verranno travasati nei campi)

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, mssContent);  //1: nel primo campo inserisco la stringa
            preparedStatement.setString(2, username); //2: nel secondo campo inserisco la stringa
            preparedStatement.setString(3, dateStr);
            preparedStatement.setString(4, prjID);

            int result = preparedStatement.executeUpdate();

            if(result>0){
                System.out.println("Row Created");
                return true;
            }
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
        return false;
    }

    public void receiveAllMss(){
        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
            String sqlQuery;
            sqlQuery = "SELECT * FROM messaggi";

            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sqlQuery);

            while(rs.next()) {
                String msgContent = rs.getString("Messaggio");
                String usrSender = rs.getString("Username");
                String dateStr = rs.getString("Data");
                System.out.println(usrSender+"> "+msgContent+" "+dateStr);
            }
        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
    }

    public void receiveLastNMss(){
        try (Connection connection = DriverManager.getConnection(databaseURL, "root", "")){
            String sqlQuery;
            int n = 10;
            sqlQuery = "SELECT * FROM (" +
                    "SELECT * FROM messaggi ORDER BY id DESC LIMIT " + n +
                    ") AS ultimeN " +
                    "ORDER BY id ASC";
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sqlQuery);

            while(rs.next()) {
                String msgContent = rs.getString("Messaggio");
                String usrSender = rs.getString("Username");
                String dateStr = rs.getString("Data");
                int id = rs.getInt("id");
                System.out.println(usrSender+"> "+msgContent+" "+dateStr+"\ttid: "+id);
            }

        }catch (SQLException ex){
            System.err.printf("Errore: ");
            ex.printStackTrace();
        }
    }

}
