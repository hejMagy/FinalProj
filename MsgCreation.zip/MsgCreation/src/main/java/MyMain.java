//import org.example.Chat;
import org.example.*;
import org.example.BaseClasses.Message;
import org.example.BaseClasses.User;

import java.util.Calendar;
import java.util.Scanner;

public class MyMain {

    public static void main(String[] args) {
        String dataBaseURL;
        dataBaseURL = "jdbc:mariadb://localhost:3306/teamsync";  //protocollo server nomeDB

        UsersManager usrManager = new UsersManager(dataBaseURL);

        int ch;
        String usrname, psw, mail, name, surname;
        Scanner scanner = new Scanner(System.in);
        Chat chat = new Chat(dataBaseURL);
        do{
            System.out.println("1 - Nuova registrazione con parametri essenziali");
            System.out.println("2 - Nuova registrazione con parametri completi");
            System.out.println("3 - Login");
            System.out.println("4 - Scrivi messaggio");
            System.out.println("-1 - Esci");
            ch = scanner.nextInt();
            scanner.nextLine();

            switch (ch){
                case 1:
                    System.out.println("Inserisci username ->");
                    usrname = scanner.nextLine();
                    System.out.println("Inserisci password ->");
                    psw = scanner.nextLine();
                    switch (usrManager.addUsr(usrname, psw)){
                        case 0:
                            System.out.println("Utente aggiunto con successo");
                            break;
                        case 1:
                            System.out.println("Utente gia' registrato");
                            break;
                        default:
                            System.out.println("Errore");

                    }
                    break;
                case 2:
                    System.out.println("Inserisci username ->");
                    usrname = scanner.nextLine();
                    System.out.println("Inserisci password ->");
                    psw = scanner.nextLine();
                    System.out.println("Inserisci mail ->");
                    mail = scanner.nextLine();
                    System.out.println("Inserisci nome ->");
                    name = scanner.nextLine();
                    System.out.println("Inserisci cognome ->");
                    surname = scanner.nextLine();
                    switch (usrManager.addUsrFull(usrname, mail, psw, name, surname)){
                        case 0:
                            System.out.println("Utente aggiunto con successo");
                            break;
                        case 1:
                            System.out.println("Utente gia' registrato");
                            break;
                        default:
                            System.out.println("Errore");

                    }
                    break;
                case 3:
                    System.out.println("Inserisci username ->");
                    usrname = scanner.nextLine();
                    System.out.println("Inserisci password ->");
                    psw = scanner.nextLine();
                    if (usrManager.login(usrname, psw)) {
                        System.out.println("Sei accesso");
                    } else {
                        System.out.println("Username e/o password errati");
                    }
                    break;
                case  4:
                    User usr = new User("Gaia", "Zhou", "gaiga", "", "jdnsj", "");
                    chat.sendMss(new Message("ciao", usr, Calendar.getInstance(), 0, 0));
                    //prjID da ottenere preventivamente appena si entra in un progetto/chat (ogni progetto ha una chat)
                    break;
                case -1:
                    System.out.println("... Sto uscendo ...");
                    break;

            }
        } while (ch != -1);
    }


}